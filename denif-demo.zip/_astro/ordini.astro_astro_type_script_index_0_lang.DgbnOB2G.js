import{_ as r}from"./preload-helper.BlTxHScW.js";async function c(){try{const{getOrders:s}=await r(async()=>{const{getOrders:e}=await import("./order-storage.DCLZc3mJ.js");return{getOrders:e}},[]),t=s();if(document.getElementById("loading")?.classList.add("hidden"),t.length===0){document.getElementById("no-orders")?.classList.remove("hidden");return}m(t)}catch(s){console.error("Error loading orders:",s),document.getElementById("loading")?.classList.add("hidden"),document.getElementById("no-orders")?.classList.remove("hidden")}}function i(s){const t={pending:{label:"In Attesa",classes:"bg-yellow-100 text-yellow-800"},confirmed:{label:"Confermato",classes:"bg-green-100 text-green-800"},processing:{label:"In Elaborazione",classes:"bg-blue-100 text-blue-800"},shipped:{label:"Spedito",classes:"bg-purple-100 text-purple-800"},delivered:{label:"Consegnato",classes:"bg-gray-100 text-gray-800"},cancelled:{label:"Cancellato",classes:"bg-red-100 text-red-800"}},e=t[s]||t.pending;return`<span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${e.classes}">${e.label}</span>`}function m(s){const t=document.getElementById("orders-list");t&&(t.classList.remove("hidden"),t.innerHTML=s.map(e=>{const a=new Date(e.createdAt),n=e.items.map(l=>l.name).join(", ");return`
				<div class="bg-white border border-neutral-200 rounded-lg p-6 hover:shadow-md transition-shadow cursor-pointer order-card"
				     data-order-id="${e.orderId}">
					<div class="flex items-start justify-between mb-4">
						<div>
							<h3 class="text-lg font-semibold" style="font-family: var(--font-display)">
								${e.orderId}
							</h3>
							<p class="text-sm text-neutral-500">
								${a.toLocaleDateString("it-IT",{year:"numeric",month:"long",day:"numeric",hour:"2-digit",minute:"2-digit"})}
							</p>
						</div>
						${i(e.status)}
					</div>

					<div class="mb-4">
						<p class="text-sm text-neutral-600 line-clamp-2">
							${e.items.length} ${e.items.length===1?"prodotto":"prodotti"}: ${n}
						</p>
					</div>

					<div class="flex items-center justify-between">
						<span class="text-lg font-semibold">€${e.totals.total.toFixed(2)}</span>
						<button class="text-sm font-medium text-neutral-900 hover:text-neutral-600 transition-colors view-details-btn"
						        data-order-id="${e.orderId}">
							Vedi Dettagli →
						</button>
					</div>
				</div>
			`}).join(""),t.querySelectorAll(".view-details-btn, .order-card").forEach(e=>{e.addEventListener("click",a=>{const n=a.currentTarget.dataset.orderId;n&&u(n)})}))}function u(s){const{getOrderById:t}=require("../lib/order-storage"),e=t(s);if(!e)return;const a=document.getElementById("order-modal"),n=document.getElementById("modal-content");if(!a||!n)return;const l=new Date(e.createdAt);n.innerHTML=`
			<h2 class="text-xl font-semibold mb-4" style="font-family: var(--font-display)">
				Ordine ${e.orderId}
			</h2>

			<div class="space-y-4">
				<div class="flex items-center justify-between">
					<span class="text-sm text-neutral-500">Data</span>
					<span class="font-medium">${l.toLocaleDateString("it-IT")}</span>
				</div>

				<div class="flex items-center justify-between">
					<span class="text-sm text-neutral-500">Stato</span>
					${i(e.status)}
				</div>

				<div class="border-t border-neutral-200 pt-4">
					<h3 class="font-semibold mb-3">Prodotti</h3>
					<div class="space-y-3">
						${e.items.map(d=>`
							<div class="flex items-center space-x-3">
								<img src="${d.image}" alt="${d.name}" class="w-12 h-12 object-cover rounded-md border border-neutral-200">
								<div class="flex-1">
									<p class="font-medium text-sm">${d.name}</p>
									<p class="text-xs text-neutral-500">Taglia: ${d.size} | Qtà: ${d.quantity}</p>
								</div>
								<p class="font-medium text-sm">€${d.subtotal.toFixed(2)}</p>
							</div>
						`).join("")}
					</div>
				</div>

				<div class="border-t border-neutral-200 pt-4 space-y-2">
					<div class="flex justify-between text-sm">
						<span class="text-neutral-600">Subtotale</span>
						<span>€${e.totals.subtotal.toFixed(2)}</span>
					</div>
					<div class="flex justify-between text-sm">
						<span class="text-neutral-600">Spedizione</span>
						<span>${e.totals.shipping===0?"Gratis":"€"+e.totals.shipping.toFixed(2)}</span>
					</div>
					<div class="flex justify-between text-lg font-semibold pt-2 border-t border-neutral-200">
						<span>Totale</span>
						<span class="text-neutral-900">€${e.totals.total.toFixed(2)}</span>
					</div>
				</div>

				${e.estimatedDelivery?`
					<div class="bg-blue-50 border border-blue-200 rounded-md p-3">
						<p class="text-sm text-blue-800">
							<strong>Consegna stimata:</strong> ${new Date(e.estimatedDelivery).toLocaleDateString("it-IT",{weekday:"long",year:"numeric",month:"long",day:"numeric"})}
						</p>
					</div>
				`:""}
			</div>
		`,a.classList.remove("hidden")}function o(){document.getElementById("order-modal")?.classList.add("hidden")}document.addEventListener("DOMContentLoaded",()=>{c(),document.getElementById("modal-backdrop")?.addEventListener("click",o),document.getElementById("close-modal")?.addEventListener("click",o),document.addEventListener("keydown",s=>{s.key==="Escape"&&o()})});
